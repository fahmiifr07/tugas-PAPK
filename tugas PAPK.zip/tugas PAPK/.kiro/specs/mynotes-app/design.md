# Dokumen Design - MyNotesApp

## Overview

MyNotesApp adalah aplikasi Flutter sederhana yang mendemonstrasikan konsep state management dan interaksi pengguna. Aplikasi ini dibangun menggunakan StatefulWidget dengan fokus pada penggunaan TextField untuk input, AnimatedContainer untuk animasi, dan setState() untuk mengelola perubahan state. 

Arsitektur aplikasi mengikuti pola sederhana dengan satu halaman utama yang mengelola semua state dan interaksi pengguna. Aplikasi ini dirancang untuk memenuhi persyaratan praktikum Flutter tentang state dan interaksi pengguna.

## Architecture

### Arsitektur Aplikasi

```
MyNotesApp (MaterialApp)
    └── MyNotesHomePage (StatefulWidget)
        ├── State Management (_MyNotesHomePageState)
        ├── UI Components (Column Layout)
        │   ├── TextField (Input nama)
        │   ├── ElevatedButton (Tombol "Ubah Tampilan")
        │   ├── Text (Sapaan)
        │   └── AnimatedContainer (Area konten animasi)
        └── Event Handlers (onPressed, onChanged)
```

### Pola Arsitektur

Aplikasi menggunakan **Widget-based State Management** yang merupakan pendekatan standar Flutter untuk aplikasi sederhana:

- **Presentation Layer**: Widget UI (TextField, Button, Text, AnimatedContainer)
- **State Layer**: _MyNotesHomePageState yang mengelola semua state aplikasi
- **Event Layer**: Callback functions untuk menangani interaksi pengguna

## Components and Interfaces

### 1. MyNotesApp (Root Widget)

**Tipe**: StatelessWidget  
**Fungsi**: Entry point aplikasi dan konfigurasi MaterialApp

```dart
class MyNotesApp extends StatelessWidget {
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyNotesApp',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: MyNotesHomePage(),
    );
  }
}
```

### 2. MyNotesHomePage (Main Page)

**Tipe**: StatefulWidget  
**Fungsi**: Halaman utama yang mengelola semua interaksi dan state

**State Variables**:
- `String _userName`: Menyimpan nama pengguna dari TextField
- `bool _isChanged`: Flag untuk menentukan apakah tampilan sudah berubah
- `Color _containerColor`: Warna untuk AnimatedContainer
- `double _containerHeight`: Tinggi untuk AnimatedContainer
- `double _containerWidth`: Lebar untuk AnimatedContainer

**Methods**:
- `_onChangeDisplay()`: Handler untuk tombol "Ubah Tampilan"
- `_onNameChanged(String value)`: Handler untuk perubahan teks di TextField

### 3. UI Components

#### TextField Component
```dart
TextField(
  onChanged: _onNameChanged,
  decoration: InputDecoration(
    labelText: 'Masukkan nama Anda',
    border: OutlineInputBorder(),
  ),
)
```

#### Button Component
```dart
ElevatedButton(
  onPressed: _onChangeDisplay,
  child: Text('Ubah Tampilan'),
)
```

#### Greeting Text Component
```dart
Text(
  _isChanged ? 'Halo, $_userName!' : '',
  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
)
```

#### AnimatedContainer Component
```dart
AnimatedContainer(
  duration: Duration(seconds: 1),
  height: _containerHeight,
  width: _containerWidth,
  decoration: BoxDecoration(
    color: _containerColor,
    borderRadius: BorderRadius.circular(10),
  ),
  child: Center(child: Text('Area Konten')),
)
```

## Data Models

### State Model

```dart
class AppState {
  String userName;           // Nama pengguna dari input
  bool isDisplayChanged;     // Status apakah tampilan sudah berubah
  Color containerColor;      // Warna container untuk animasi
  double containerHeight;    // Tinggi container
  double containerWidth;     // Lebar container
  
  AppState({
    this.userName = '',
    this.isDisplayChanged = false,
    this.containerColor = Colors.blue,
    this.containerHeight = 100.0,
    this.containerWidth = 200.0,
  });
}
```

### Animation State Model

```dart
class AnimationState {
  Color currentColor;
  Color targetColor;
  double currentHeight;
  double targetHeight;
  double currentWidth;
  double targetWidth;
  
  AnimationState.initial() :
    currentColor = Colors.blue,
    targetColor = Colors.green,
    currentHeight = 100.0,
    targetHeight = 150.0,
    currentWidth = 200.0,
    targetWidth = 250.0;
}
```

## Correctness Properties

*Property adalah karakteristik atau perilaku yang harus berlaku benar di semua eksekusi sistem yang valid - pada dasarnya, pernyataan formal tentang apa yang harus dilakukan sistem. Property berfungsi sebagai jembatan antara spesifikasi yang dapat dibaca manusia dan jaminan kebenaran yang dapat diverifikasi mesin.*

Sebelum menulis correctness properties, saya perlu menganalisis acceptance criteria dari requirements untuk menentukan mana yang dapat diuji sebagai property.

<function_calls>
<invoke name="prework">
<parameter name="featureName">mynotes-app

### Property Reflection

Setelah menganalisis semua acceptance criteria, saya mengidentifikasi beberapa property yang dapat digabungkan untuk menghindari redundansi:

- Property 2.2 (state berubah saat tombol ditekan) dan Property 4.1 (AnimatedContainer berubah saat tombol ditekan) dapat digabungkan menjadi satu property komprehensif tentang perubahan state dan UI
- Property 3.1 (format sapaan) dan Property 3.3 (update sapaan) dapat digabungkan menjadi satu property tentang sapaan yang konsisten
- Property 6.2 (UI update konsisten) dan Property 6.3 (persistensi state) dapat digabungkan menjadi satu property tentang state management

Berdasarkan analisis prework, berikut adalah correctness properties yang akan diimplementasikan:

### Property 1: Input State Synchronization
*Untuk setiap* string yang dimasukkan ke TextField, state aplikasi harus mencerminkan input tersebut dengan akurat
**Validates: Requirements 1.2**

### Property 2: Button Press State Changes
*Untuk setiap* penekanan tombol "Ubah Tampilan", aplikasi harus mengubah state dan memperbarui tampilan AnimatedContainer dengan properti visual yang berbeda
**Validates: Requirements 2.2, 4.1, 4.3**

### Property 3: Consistent Button Response
*Untuk setiap* penekanan tombol berulang, aplikasi harus memberikan respons yang konsisten dalam mengubah state
**Validates: Requirements 2.4**

### Property 4: Greeting Format Consistency
*Untuk setiap* nama pengguna yang dimasukkan, sapaan yang ditampilkan harus mengikuti format "Halo, <nama>!" dan diperbarui sesuai dengan perubahan nama
**Validates: Requirements 3.1, 3.3**

### Property 5: Animation State Persistence
*Untuk setiap* perubahan tampilan yang terjadi, AnimatedContainer harus mempertahankan tampilan baru hingga interaksi berikutnya
**Validates: Requirements 4.4**

### Property 6: Performance Response Time
*Untuk setiap* interaksi pengguna, aplikasi harus merespons dalam waktu kurang dari 100ms
**Validates: Requirements 6.1**

### Property 7: State Management Consistency
*Untuk setiap* perubahan state, UI harus diperbarui secara konsisten tanpa error dan state harus dipertahankan selama sesi penggunaan
**Validates: Requirements 6.2, 6.3**

### Property 8: Layout Responsiveness
*Untuk setiap* perubahan orientasi atau resize, aplikasi harus tetap berfungsi dengan baik tanpa kehilangan state atau functionality
**Validates: Requirements 6.4**

## Error Handling

### Input Validation
- **Empty Input**: Aplikasi harus dapat menangani input kosong tanpa crash
- **Whitespace Input**: Input yang hanya berisi spasi harus diproses dengan benar
- **Special Characters**: Nama dengan karakter khusus harus ditampilkan dengan benar dalam sapaan

### State Management Errors
- **setState() Errors**: Implementasi try-catch untuk menangani potential errors dalam setState()
- **Widget Lifecycle**: Memastikan setState() tidak dipanggil setelah widget di-dispose

### Animation Errors
- **Animation Duration**: Menangani kasus di mana animasi mungkin terganggu oleh interaksi cepat
- **Container Properties**: Validasi bahwa properti AnimatedContainer selalu dalam range yang valid

### Error Recovery
```dart
void _onChangeDisplay() {
  try {
    setState(() {
      _isChanged = true;
      _containerColor = _containerColor == Colors.blue ? Colors.green : Colors.blue;
      _containerHeight = _containerHeight == 100.0 ? 150.0 : 100.0;
      _containerWidth = _containerWidth == 200.0 ? 250.0 : 200.0;
    });
  } catch (e) {
    // Log error dan maintain current state
    debugPrint('Error updating display: $e');
  }
}
```

## Testing Strategy

### Dual Testing Approach

Aplikasi MyNotesApp akan menggunakan kombinasi **unit testing** dan **property-based testing** untuk memastikan kebenaran dan keandalan:

**Unit Tests**:
- Menguji contoh spesifik dan edge cases
- Memverifikasi widget tree structure
- Menguji error conditions dan input validation
- Fokus pada integration points antar komponen

**Property Tests**:
- Memverifikasi universal properties di semua input
- Menggunakan randomized testing untuk comprehensive coverage
- Menguji invariants dan behavioral consistency
- Memvalidasi performance requirements

### Property-Based Testing Configuration

**Testing Library**: Akan menggunakan `test` package Flutter dengan custom property testing utilities atau `faker` untuk data generation.

**Test Configuration**:
- Minimum 100 iterasi per property test
- Setiap property test harus reference design document property
- Tag format: **Feature: mynotes-app, Property {number}: {property_text}**

**Property Test Examples**:

```dart
// Property 1: Input State Synchronization
testWidgets('Property 1: Input state synchronization', (WidgetTester tester) async {
  // Feature: mynotes-app, Property 1: Input State Synchronization
  for (int i = 0; i < 100; i++) {
    final randomInput = generateRandomString();
    await tester.pumpWidget(MyNotesApp());
    
    await tester.enterText(find.byType(TextField), randomInput);
    await tester.pump();
    
    final state = tester.state<_MyNotesHomePageState>(find.byType(MyNotesHomePage));
    expect(state._userName, equals(randomInput));
  }
});

// Property 4: Greeting Format Consistency
testWidgets('Property 4: Greeting format consistency', (WidgetTester tester) async {
  // Feature: mynotes-app, Property 4: Greeting Format Consistency
  for (int i = 0; i < 100; i++) {
    final randomName = generateRandomName();
    await tester.pumpWidget(MyNotesApp());
    
    await tester.enterText(find.byType(TextField), randomName);
    await tester.tap(find.text('Ubah Tampilan'));
    await tester.pump();
    
    expect(find.text('Halo, $randomName!'), findsOneWidget);
  }
});
```

### Unit Testing Balance

**Unit tests akan fokus pada**:
- Widget initialization state (TextField kosong, tombol tersedia)
- Specific examples dari greeting format
- Edge cases (empty input, whitespace input)
- Widget tree structure validation
- Error handling scenarios

**Property tests akan fokus pada**:
- Input synchronization across all possible strings
- State consistency across multiple interactions
- Animation behavior across different states
- Performance requirements validation

### Test Coverage Goals

- **Widget Tests**: 100% coverage untuk semua UI components
- **Unit Tests**: 90% coverage untuk business logic
- **Property Tests**: Semua 8 correctness properties harus diimplementasikan
- **Integration Tests**: End-to-end flow dari input hingga display update

Kombinasi pendekatan ini memastikan bahwa aplikasi tidak hanya berfungsi untuk kasus-kasus spesifik, tetapi juga mempertahankan kebenaran universal di semua kemungkinan input dan interaksi pengguna.