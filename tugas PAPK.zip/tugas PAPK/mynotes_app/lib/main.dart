import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:convert';
import 'add_note_view_simple.dart';
import 'note_detail_view.dart';
import 'custom_error_widget.dart';

// Use simple storage service
import 'storage_service_simple.dart';

void main() {
  // Disable overflow indicator secara global
  WidgetsFlutterBinding.ensureInitialized();
  
  // Setup custom error widget
  CustomErrorWidget.setupCustomErrorWidget();
  
  // Disable debug painting dan overflow indicators
  debugPaintSizeEnabled = false;
  
  // Disable all debug indicators
  debugDisableClipLayers = true;
  debugDisableOpacityLayers = true;
  debugDisablePhysicalShapeLayers = true;
  
  runApp(const MyNotesApp());
}

/// MyNotesApp adalah root widget aplikasi yang mengkonfigurasi MaterialApp
/// dengan theme, title, dan named routes untuk navigasi antar halaman.
class MyNotesApp extends StatelessWidget {
  const MyNotesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyNotesApp',
      debugShowCheckedModeBanner: false, // Hapus debug banner
      debugShowMaterialGrid: false, // Hapus material grid
      showPerformanceOverlay: false, // Hapus performance overlay
      showSemanticsDebugger: false, // Hapus semantics debugger
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
        // Disable overflow indicator
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      // Custom builder to wrap with error handling
      builder: (context, child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
          child: child ?? const SizedBox(),
        );
      },
      // Named Routes untuk navigasi
      initialRoute: '/',
      routes: {
        '/': (context) => const MyNotesHomePage(),
        '/add_note': (context) => const AddNoteViewSimple(),
      },
      // Route generator untuk passing data ke halaman detail dan edit
      onGenerateRoute: (settings) {
        if (settings.name == '/note_detail') {
          final note = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (context) => NoteDetailView(note: note),
          );
        } else if (settings.name == '/edit_note') {
          final note = settings.arguments as Map<String, dynamic>;
          return MaterialPageRoute(
            builder: (context) => AddNoteViewSimple(editNote: note),
          );
        }
        return null;
      },
    );
  }
}

/// MyNotesHomePage adalah halaman utama aplikasi yang mengelola
/// semua interaksi pengguna, state management, dan navigasi ke halaman lain.
class MyNotesHomePage extends StatefulWidget {
  const MyNotesHomePage({super.key});

  @override
  State<MyNotesHomePage> createState() => _MyNotesHomePageState();
}

class _MyNotesHomePageState extends State<MyNotesHomePage> {
  // State variables untuk mengelola state aplikasi
  String _userName = '';
  bool _isChanged = false;
  Color _containerColor = Colors.blue;
  double _containerHeight = 100.0;
  double _containerWidth = 200.0;
  
  // Daftar catatan untuk demonstrasi navigasi
  final List<Map<String, dynamic>> _notes = [];
  
  @override
  void initState() {
    super.initState();
    _loadNotes(); // Load catatan saat aplikasi dimulai
  }

  /// Handler untuk perubahan teks di TextField.
  /// Menyimpan input pengguna ke dalam state _userName.
  /// 
  /// Parameter:
  /// - [value]: String input dari pengguna
  void _onNameChanged(String value) {
    // Safety check: pastikan widget masih mounted sebelum setState()
    if (!mounted) return;
    
    try {
      setState(() {
        _userName = value;
      });
    } catch (e) {
      // Log error untuk debugging dan maintain current state
      debugPrint('Error updating user name: $e');
    }
  }

  /// Load catatan dari storage
  void _loadNotes() async {
    try {
      print('🔄 Loading notes on app start...');
      final loadedNotes = await StorageServiceSimple.loadNotes();
      setState(() {
        _notes.clear();
        _notes.addAll(loadedNotes);
      });
      print('✅ Notes loaded: ${_notes.length} notes');
      
      // Debug storage
      StorageServiceSimple.debugStorage();
    } catch (e) {
      debugPrint('❌ Error loading notes: $e');
    }
  }

  /// Save catatan ke storage
  void _saveNotes() async {
    try {
      print('💾 Saving ${_notes.length} notes...');
      await StorageServiceSimple.saveNotes(_notes);
      print('✅ Notes saved successfully');
      
      // Debug storage after save
      StorageServiceSimple.debugStorage();
    } catch (e) {
      debugPrint('❌ Error saving notes: $e');
    }
  }

  /// Navigasi ke halaman Tambah Catatan menggunakan Named Routes
  void _navigateToAddNote() async {
    final result = await Navigator.pushNamed(context, '/add_note');
    
    if (result != null && result is Map<String, dynamic>) {
      setState(() {
        _notes.add(result);
      });
      _saveNotes(); // Save setelah menambah catatan
      
      // Tampilkan snackbar konfirmasi
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Catatan berhasil ditambahkan!'),
            backgroundColor: Colors.green,
          ),
        );
      }
    }
  }

  /// Navigasi ke halaman Detail Catatan menggunakan Navigator.push()
  void _navigateToNoteDetail(Map<String, dynamic> note, int index) async {
    final result = await Navigator.pushNamed(
      context, 
      '/note_detail', 
      arguments: {'note': note, 'index': index},
    );
    
    if (result == 'delete') {
      setState(() {
        _notes.removeAt(index);
      });
      _saveNotes(); // Save setelah menghapus catatan
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Catatan berhasil dihapus!'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } else if (result is Map<String, dynamic> && result['action'] == 'edit') {
      // Navigate to edit page
      _navigateToEditNote(note, index);
    }
  }

  /// Navigasi ke halaman Edit Catatan
  void _navigateToEditNote(Map<String, dynamic> note, int index) async {
    final result = await Navigator.pushNamed(
      context,
      '/edit_note',
      arguments: note,
    );
    
    if (result != null && result is Map<String, dynamic>) {
      setState(() {
        _notes[index] = result;
      });
      _saveNotes(); // Save setelah mengedit catatan
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Catatan berhasil diperbarui!'),
            backgroundColor: Colors.blue,
          ),
        );
      }
    }
  }

  /// Handler untuk tombol "Ubah Tampilan".
  /// Mengubah state untuk memicu perubahan tampilan dan animasi.
  /// Implementasi toggle logic untuk warna dan ukuran container.
  void _onChangeDisplay() {
    // Safety check: pastikan widget masih mounted sebelum setState()
    if (!mounted) return;
    
    try {
      setState(() {
        _isChanged = true;
        // Toggle warna container antara blue dan green
        _containerColor = _containerColor == Colors.blue ? Colors.green : Colors.blue;
        // Toggle ukuran container
        _containerHeight = _containerHeight == 100.0 ? 150.0 : 100.0;
        _containerWidth = _containerWidth == 200.0 ? 250.0 : 200.0;
      });
    } catch (e) {
      // Log error untuk debugging
      debugPrint('Error updating display state: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MyNotesApp'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Spacer untuk memberikan ruang di atas
                const SizedBox(height: 20),
                
                // TextField untuk input nama pengguna
                TextField(
                  onChanged: _onNameChanged,
                  decoration: const InputDecoration(
                    labelText: 'Masukkan nama Anda',
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 16.0, 
                      vertical: 12.0,
                    ),
                  ),
                  maxLength: 50,
                  buildCounter: (context, {required currentLength, required isFocused, maxLength}) {
                    // Hide counter untuk UI yang lebih bersih
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                
                // Tombol "Ubah Tampilan"
                ElevatedButton(
                  onPressed: _onChangeDisplay,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16.0),
                  ),
                  child: const Text(
                    'Ubah Tampilan',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
                const SizedBox(height: 32),
                
                // Sapaan personal (ditampilkan jika _isChanged = true)
                if (_isChanged) _buildGreetingText(),
                
                // Statistik catatan (jika ada catatan)
                if (_notes.isNotEmpty) _buildStatsCard(),
                
                // AnimatedContainer untuk efek animasi
                Center(
                  child: AnimatedContainer(
                    duration: const Duration(seconds: 1),
                    curve: Curves.easeInOut,
                    height: _containerHeight,
                    width: _containerWidth,
                    decoration: BoxDecoration(
                      color: _containerColor,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.1),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text(
                        'Area Konten',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 32),
                
                // Daftar Catatan
                if (_notes.isNotEmpty) ...[
                  // Header daftar catatan
                  Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.green.shade200),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.list_alt, color: Colors.green),
                        const SizedBox(width: 8),
                        Text(
                          'Daftar Catatan (${_notes.length})',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                        const Spacer(),
                        Text(
                          'Total: ${_notes.length} catatan',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  
                  // ListView catatan dengan fixed height
                  Container(
                    height: 300,
                    child: ListView.builder(
                      itemCount: _notes.length,
                      itemBuilder: (context, index) {
                        final note = _notes[index];
                        final timestamp = note['timestamp'] as DateTime;
                        
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          elevation: 2,
                          child: ListTile(
                            contentPadding: const EdgeInsets.all(16),
                            leading: CircleAvatar(
                              backgroundColor: Colors.blue.shade100,
                              child: Text(
                                '${index + 1}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue,
                                ),
                              ),
                            ),
                            title: Text(
                              note['title'] ?? 'Tanpa Judul',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                Text(
                                  note['content'] ?? 'Tidak ada konten',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    Icon(
                                      Icons.access_time,
                                      size: 14,
                                      color: Colors.grey.shade500,
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${timestamp.day}/${timestamp.month}/${timestamp.year} ${timestamp.hour}:${timestamp.minute.toString().padLeft(2, '0')}',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey.shade500,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            trailing: const Icon(
                              Icons.arrow_forward_ios,
                              size: 16,
                              color: Colors.grey,
                            ),
                            onTap: () => _navigateToNoteDetail(note, index),
                          ),
                        );
                      },
                    ),
                  ),
                ] else ...[
                  // Empty state
                  Container(
                    height: 200,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.note_add,
                            size: 80,
                            color: Colors.grey.shade300,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Belum ada catatan',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey.shade600,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Tekan tombol + untuk menambah catatan pertama',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade500,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                
                // Bottom spacing
                const SizedBox(height: 80),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _navigateToAddNote,
        tooltip: 'Tambah Catatan Baru',
        icon: const Icon(Icons.add),
        label: const Text('Tambah Catatan'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
    );
  }
  
  /// Membangun widget untuk menampilkan sapaan personal.
  /// 
  /// Returns: Widget yang menampilkan teks sapaan dengan format "Halo, [nama]!"
  Widget _buildGreetingText() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 32.0),
      child: Text(
        'Halo, $_userName!',
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.blue,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  /// Membangun widget untuk menampilkan statistik catatan
  Widget _buildStatsCard() {
    final totalNotes = _notes.length;
    final totalCharacters = _notes.fold<int>(
      0, 
      (sum, note) => sum + (note['content']?.toString().length ?? 0),
    );
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Card(
        color: Colors.orange.shade50,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  const Icon(Icons.note, color: Colors.orange),
                  const SizedBox(height: 4),
                  Text(
                    '$totalNotes',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange,
                    ),
                  ),
                  const Text(
                    'Catatan',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.orange,
                    ),
                  ),
                ],
              ),
              Container(
                height: 40,
                width: 1,
                color: Colors.orange.shade200,
              ),
              Column(
                children: [
                  const Icon(Icons.text_fields, color: Colors.orange),
                  const SizedBox(height: 4),
                  Text(
                    '$totalCharacters',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange,
                    ),
                  ),
                  const Text(
                    'Karakter',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.orange,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}