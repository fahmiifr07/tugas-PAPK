// For mobile platforms, we'll use a simple in-memory storage
// In a real app, you would use shared_preferences or sqflite

class StorageImpl {
  static final Map<String, String> _storage = {};
  
  static Future<void> setString(String key, String value) async {
    _storage[key] = value;
  }
  
  static Future<String?> getString(String key) async {
    return _storage[key];
  }
}