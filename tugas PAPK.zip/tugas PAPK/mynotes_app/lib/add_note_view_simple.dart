import 'package:flutter/material.dart';
import 'no_overflow_wrapper.dart';

/// Halaman Tambah Catatan - Versi Simple tanpa Overflow
class AddNoteViewSimple extends StatefulWidget {
  final Map<String, dynamic>? editNote; // Note untuk di-edit (optional)
  
  const AddNoteViewSimple({super.key, this.editNote});

  @override
  State<AddNoteViewSimple> createState() => _AddNoteViewSimpleState();
}

class _AddNoteViewSimpleState extends State<AddNoteViewSimple> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  
  // Validation state
  String? _titleError;
  String? _contentError;
  
  // Edit mode flag
  bool get _isEditMode => widget.editNote != null;

  @override
  void initState() {
    super.initState();
    // Jika dalam edit mode, isi form dengan data existing
    if (_isEditMode) {
      _titleController.text = widget.editNote!['title'] ?? '';
      _contentController.text = widget.editNote!['content'] ?? '';
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  /// Validasi form input
  bool _validateForm() {
    setState(() {
      _titleError = null;
      _contentError = null;
    });

    bool isValid = true;

    // Validasi judul catatan
    if (_titleController.text.trim().isEmpty) {
      setState(() {
        _titleError = 'Judul catatan tidak boleh kosong';
      });
      isValid = false;
    } else if (_titleController.text.trim().length < 3) {
      setState(() {
        _titleError = 'Judul catatan minimal 3 karakter';
      });
      isValid = false;
    }

    // Validasi isi catatan
    if (_contentController.text.trim().isEmpty) {
      setState(() {
        _contentError = 'Isi catatan tidak boleh kosong';
      });
      isValid = false;
    } else if (_contentController.text.trim().length < 10) {
      setState(() {
        _contentError = 'Isi catatan minimal 10 karakter';
      });
      isValid = false;
    }

    return isValid;
  }

  /// Simpan catatan dan kembali ke halaman sebelumnya
  void _saveNote() {
    // Validasi form terlebih dahulu
    if (!_validateForm()) {
      // Tampilkan pesan error jika validasi gagal
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Mohon perbaiki kesalahan pada form!'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    // Jika validasi berhasil, simpan catatan
    final noteData = {
      'title': _titleController.text.trim(),
      'content': _contentController.text.trim(),
      'timestamp': _isEditMode ? widget.editNote!['timestamp'] : DateTime.now(),
      'id': _isEditMode ? widget.editNote!['id'] : DateTime.now().millisecondsSinceEpoch.toString(),
      'lastModified': DateTime.now(), // Tambah field last modified
    };

    // Kembali ke halaman sebelumnya dengan data catatan
    Navigator.pop(context, noteData);
  }

  @override
  Widget build(BuildContext context) {
    return NoOverflowWrapper(
      child: Scaffold(
        appBar: AppBar(
          title: Text(_isEditMode ? 'Edit Catatan' : 'Tambah Catatan'),
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          actions: [
            IconButton(
              onPressed: _saveNote,
              icon: const Icon(Icons.save),
              tooltip: _isEditMode ? 'Simpan Perubahan' : 'Simpan Catatan',
            ),
          ],
        ),
        resizeToAvoidBottomInset: true,
        body: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(16.0),
            children: [
              // Header info
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '📝 Form Input Catatan',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Lengkapi form di bawah untuk menambah catatan baru',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.blue,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // TextField untuk judul catatan
              const Text(
                'Judul Catatan *',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _titleController,
                decoration: InputDecoration(
                  labelText: 'Masukkan judul catatan',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.title),
                  errorText: _titleError,
                  helperText: 'Minimal 3 karakter',
                ),
                textInputAction: TextInputAction.next,
                maxLength: 50,
                onChanged: (value) {
                  setState(() {
                    if (_titleError != null) {
                      _titleError = null;
                    }
                  });
                },
              ),
              const SizedBox(height: 16),
              
              // TextField untuk konten catatan
              const Text(
                'Isi Catatan *',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _contentController,
                decoration: InputDecoration(
                  labelText: 'Tulis isi catatan di sini...',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.note),
                  alignLabelWithHint: true,
                  errorText: _contentError,
                  helperText: 'Minimal 10 karakter',
                ),
                maxLines: 5,
                textAlignVertical: TextAlignVertical.top,
                onChanged: (value) {
                  setState(() {
                    if (_contentError != null) {
                      _contentError = null;
                    }
                  });
                },
              ),
              const SizedBox(height: 24),
              
              // Tombol Simpan
              ElevatedButton.icon(
                onPressed: _saveNote,
                icon: const Icon(Icons.save),
                label: Text(_isEditMode ? 'Simpan Perubahan' : 'Simpan Catatan'),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  backgroundColor: _isEditMode ? Colors.orange : Colors.green,
                  foregroundColor: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              
              // Tombol Batal
              OutlinedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.cancel),
                label: const Text('Batal'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  foregroundColor: Colors.red,
                ),
              ),
              
              // Extra space for keyboard
              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }
}