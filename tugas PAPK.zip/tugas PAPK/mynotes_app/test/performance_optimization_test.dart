import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Performance Optimization Tests', () {
    testWidgets('TextEditingController is properly initialized and disposed', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Verify TextField exists and works
      expect(find.byType(TextField), findsOneWidget);
      
      // Test input functionality
      await tester.enterText(find.byType(TextField), 'Performance Test');
      await tester.pump();
      
      // Verify input is reflected in state
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, Performance Test!'), findsOneWidget);
      
      // Widget should dispose cleanly without errors
      await tester.pumpWidget(Container());
    });
    
    testWidgets('Rapid button taps are handled gracefully', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Enter some text first
      await tester.enterText(find.byType(TextField), 'Rapid Test');
      await tester.pump();
      
      // Perform rapid button taps
      for (int i = 0; i < 5; i++) {
        await tester.tap(find.text('Ubah Tampilan'));
        await tester.pump(const Duration(milliseconds: 10)); // Very short delay
      }
      
      // App should still be functional and show greeting
      expect(find.text('Halo, Rapid Test!'), findsOneWidget);
      expect(find.text('Area Konten'), findsOneWidget);
    });
    
    testWidgets('TextField input length is limited for performance', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Try to enter very long text (more than 50 characters)
      const longText = 'This is a very long text that exceeds the maximum length limit of fifty characters';
      await tester.enterText(find.byType(TextField), longText);
      await tester.pump();
      
      // Get the actual text in the TextField
      final textField = tester.widget<TextField>(find.byType(TextField));
      final actualText = textField.controller?.text ?? '';
      
      // Text should be limited to 50 characters or less
      expect(actualText.length, lessThanOrEqualTo(50));
    });
    
    testWidgets('Greeting transitions work smoothly', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Initially no greeting should be visible
      expect(find.textContaining('Halo,'), findsNothing);
      
      // Enter text and trigger display change
      await tester.enterText(find.byType(TextField), 'Animation Test');
      await tester.pump();
      
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Greeting should appear
      expect(find.text('Halo, Animation Test!'), findsOneWidget);
      
      // Verify greeting text widget is present and properly styled
      final greetingWidget = tester.widget<Text>(find.text('Halo, Animation Test!'));
      expect(greetingWidget.style?.fontSize, equals(20));
      expect(greetingWidget.style?.fontWeight, equals(FontWeight.bold));
    });
    
    testWidgets('AnimatedContainer has smooth curve animation', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Find the AnimatedContainer
      expect(find.byType(AnimatedContainer), findsOneWidget);
      
      // Trigger animation
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Let animation run for a bit
      await tester.pump(const Duration(milliseconds: 500));
      
      // Container should still be present and functional
      expect(find.byType(AnimatedContainer), findsOneWidget);
      expect(find.text('Area Konten'), findsOneWidget);
    });
    
    testWidgets('Multiple state changes work without memory leaks', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Perform multiple operations to test for memory leaks
      for (int i = 0; i < 10; i++) {
        await tester.enterText(find.byType(TextField), 'Test $i');
        await tester.pump();
        
        await tester.tap(find.text('Ubah Tampilan'));
        await tester.pump();
        
        expect(find.text('Halo, Test $i!'), findsOneWidget);
      }
      
      // App should still be responsive
      expect(find.byType(TextField), findsOneWidget);
      expect(find.text('Ubah Tampilan'), findsOneWidget);
      expect(find.text('Area Konten'), findsOneWidget);
    });
  });
}