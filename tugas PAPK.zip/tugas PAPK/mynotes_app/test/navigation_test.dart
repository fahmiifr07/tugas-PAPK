import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Navigation Tests - Tugas Pertemuan 4', () {
    testWidgets('FloatingActionButton should be present for navigation', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Verify FloatingActionButton is present
      expect(find.byType(FloatingActionButton), findsOneWidget);
      expect(find.byIcon(Icons.add), findsOneWidget);
    });

    testWidgets('App should have proper named routes configuration', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Verify initial route loads correctly
      expect(find.text('MyNotesApp'), findsOneWidget);
      expect(find.text('Masukkan nama Anda'), findsOneWidget);
    });

    testWidgets('Should show empty notes list initially', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Initially, no notes should be present
      expect(find.text('Daftar Catatan:'), findsNothing);
      expect(find.byType(ListView), findsNothing);
    });

    testWidgets('Should navigate to AddNoteView when FAB is tapped', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Tap the FloatingActionButton
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();

      // Should navigate to AddNoteView
      expect(find.text('Tambah Catatan'), findsOneWidget);
      expect(find.text('Judul Catatan'), findsOneWidget);
      expect(find.text('Isi Catatan'), findsOneWidget);
    });

    testWidgets('Should be able to go back from AddNoteView', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Navigate to AddNoteView
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();

      // Verify we're in AddNoteView
      expect(find.text('Tambah Catatan'), findsOneWidget);

      // Tap back button or cancel button
      await tester.tap(find.text('Batal'));
      await tester.pumpAndSettle();

      // Should be back to home page
      expect(find.text('MyNotesApp'), findsOneWidget);
      expect(find.text('Masukkan nama Anda'), findsOneWidget);
    });

    testWidgets('Should save note and return to home page', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Navigate to AddNoteView
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();

      // Fill in the form
      await tester.enterText(find.byType(TextField).first, 'Test Title');
      await tester.enterText(find.byType(TextField).last, 'Test Content');

      // Save the note
      await tester.tap(find.text('Simpan Catatan'));
      await tester.pumpAndSettle();

      // Should be back to home page with the note added
      expect(find.text('MyNotesApp'), findsOneWidget);
      expect(find.text('Daftar Catatan:'), findsOneWidget);
      expect(find.text('Test Title'), findsOneWidget);
    });

    testWidgets('Should navigate to note detail when note is tapped', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Add a note first
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();
      await tester.enterText(find.byType(TextField).first, 'Detail Test');
      await tester.enterText(find.byType(TextField).last, 'Detail Content');
      await tester.tap(find.text('Simpan Catatan'));
      await tester.pumpAndSettle();

      // Tap on the note to view details
      await tester.tap(find.text('Detail Test'));
      await tester.pumpAndSettle();

      // Should be in detail view
      expect(find.text('Detail Test'), findsAtLeastNWidgets(1));
      expect(find.text('Detail Content'), findsOneWidget);
      expect(find.text('Judul:'), findsOneWidget);
      expect(find.text('Isi Catatan:'), findsOneWidget);
    });

    testWidgets('Should be able to go back from detail view', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Add a note and navigate to detail
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();
      await tester.enterText(find.byType(TextField).first, 'Back Test');
      await tester.enterText(find.byType(TextField).last, 'Back Content');
      await tester.tap(find.text('Simpan Catatan'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Back Test'));
      await tester.pumpAndSettle();

      // Go back from detail view
      await tester.tap(find.text('Kembali'));
      await tester.pumpAndSettle();

      // Should be back to home page
      expect(find.text('MyNotesApp'), findsOneWidget);
      expect(find.text('Daftar Catatan:'), findsOneWidget);
    });

    testWidgets('Should show validation error for empty fields', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Navigate to AddNoteView
      await tester.tap(find.byType(FloatingActionButton));
      await tester.pumpAndSettle();

      // Try to save without filling fields
      await tester.tap(find.text('Simpan Catatan'));
      await tester.pumpAndSettle();

      // Should show error message
      expect(find.text('Judul dan konten tidak boleh kosong!'), findsOneWidget);
    });

    testWidgets('All required widgets should be present in home page', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Verify all required widgets from Tugas Pertemuan 3 are still present
      expect(find.byType(TextField), findsOneWidget);
      expect(find.text('Ubah Tampilan'), findsOneWidget);
      expect(find.byType(AnimatedContainer), findsOneWidget);
      expect(find.text('Area Konten'), findsOneWidget);

      // Verify new navigation elements
      expect(find.byType(FloatingActionButton), findsOneWidget);
    });
  });
}