import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Manual Functionality Validation', () {
    testWidgets('Complete user flow - input name, press button, see results', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // 1. Verify initial state
      expect(find.text('MyNotesApp'), findsOneWidget);
      expect(find.text('Masukkan nama Anda'), findsOneWidget);
      expect(find.text('Ubah Tampilan'), findsOneWidget);
      expect(find.text('Area Konten'), findsOneWidget);
      expect(find.textContaining('Halo,'), findsNothing);

      // 2. Test TextField input
      await tester.enterText(find.byType(TextField), 'Test User');
      await tester.pump();

      // 3. Test button press and state changes
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // 4. Verify greeting appears
      expect(find.text('Halo, Test User!'), findsOneWidget);

      // 5. Verify AnimatedContainer is present (we can't easily test animation changes in unit tests)
      expect(find.byType(AnimatedContainer), findsOneWidget);

      // 6. Test multiple button presses
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Greeting should still be there
      expect(find.text('Halo, Test User!'), findsOneWidget);

      // 7. Test name change
      await tester.enterText(find.byType(TextField), 'New User');
      await tester.pump();

      // Old greeting should still be there until button is pressed
      expect(find.text('Halo, Test User!'), findsOneWidget);

      // Press button to update
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // New greeting should appear
      expect(find.text('Halo, New User!'), findsOneWidget);
      expect(find.text('Halo, Test User!'), findsNothing);
    });

    testWidgets('Edge cases validation', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      // Test empty name
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, !'), findsOneWidget);

      // Test whitespace name
      await tester.enterText(find.byType(TextField), '   ');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo,    !'), findsOneWidget);

      // Test special characters
      await tester.enterText(find.byType(TextField), 'José-María');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, José-María!'), findsOneWidget);
    });

    testWidgets('Widget structure validation', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());

      // Verify all required widgets are present
      expect(find.byType(MaterialApp), findsOneWidget);
      expect(find.byType(Scaffold), findsOneWidget);
      expect(find.byType(AppBar), findsOneWidget);
      expect(find.byType(Column), findsOneWidget);
      expect(find.byType(TextField), findsOneWidget);
      expect(find.byType(ElevatedButton), findsOneWidget);
      expect(find.byType(AnimatedContainer), findsOneWidget);
      expect(find.byType(Padding), findsAtLeastNWidgets(1));
      expect(find.byType(SizedBox), findsAtLeastNWidgets(1));
    });
  });
}