import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Animation Logic Tests', () {
    testWidgets('_onChangeDisplay should toggle container properties correctly', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Find the button
      final button = find.text('Ubah Tampilan');
      expect(button, findsOneWidget);
      
      // Get initial AnimatedContainer properties
      final containerFinder = find.byType(AnimatedContainer);
      AnimatedContainer initialContainer = tester.widget(containerFinder);
      expect((initialContainer.decoration as BoxDecoration).color, Colors.blue);
      
      // Tap the button to trigger _onChangeDisplay
      await tester.tap(button);
      await tester.pump();
      
      // Verify container properties changed after first tap
      AnimatedContainer updatedContainer = tester.widget(containerFinder);
      expect((updatedContainer.decoration as BoxDecoration).color, Colors.green);
      
      // Tap again to test toggle behavior
      await tester.tap(button);
      await tester.pump();
      
      // Verify toggle back to original values
      AnimatedContainer toggledContainer = tester.widget(containerFinder);
      expect((toggledContainer.decoration as BoxDecoration).color, Colors.blue);
    });
    
    testWidgets('Greeting should appear after button press', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Enter a name
      await tester.enterText(find.byType(TextField), 'Test User');
      await tester.pump();
      
      // Initially, greeting should not be visible
      expect(find.text('Halo, Test User!'), findsNothing);
      
      // Tap the button
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Now greeting should be visible
      expect(find.text('Halo, Test User!'), findsOneWidget);
    });
    
    testWidgets('AnimatedContainer should have correct properties after toggle', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Find the AnimatedContainer
      final animatedContainer = find.byType(AnimatedContainer);
      expect(animatedContainer, findsOneWidget);
      
      // Get initial container widget
      AnimatedContainer initialContainer = tester.widget(animatedContainer);
      expect((initialContainer.decoration as BoxDecoration).color, Colors.blue);
      
      // Tap the button to trigger animation
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Get updated container widget
      AnimatedContainer updatedContainer = tester.widget(animatedContainer);
      expect((updatedContainer.decoration as BoxDecoration).color, Colors.green);
      
      // Verify animation properties
      expect(updatedContainer.duration, const Duration(seconds: 1));
      expect(updatedContainer.curve, Curves.easeInOut);
    });
  });
}