import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('ElevatedButton Tests', () {
    testWidgets('Button should be present with correct label', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Verify that the button exists with correct label
      expect(find.text('Ubah Tampilan'), findsOneWidget);
      expect(find.byType(ElevatedButton), findsOneWidget);
    });

    testWidgets('Button should trigger state changes when pressed', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Initially, greeting should not be visible
      expect(find.textContaining('Halo,'), findsNothing);

      // Tap the button
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // After tapping, greeting should be visible (even if empty name)
      expect(find.textContaining('Halo,'), findsOneWidget);
    });

    testWidgets('Button should change AnimatedContainer properties', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Find the AnimatedContainer
      final containerFinder = find.byType(AnimatedContainer);
      expect(containerFinder, findsOneWidget);

      // Get initial container
      AnimatedContainer initialContainer = tester.widget(containerFinder);
      
      // Tap the button
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Get updated container
      AnimatedContainer updatedContainer = tester.widget(containerFinder);
      
      // Verify that decoration color has changed
      final initialDecoration = initialContainer.decoration as BoxDecoration;
      final updatedDecoration = updatedContainer.decoration as BoxDecoration;
      expect(initialDecoration.color != updatedDecoration.color, isTrue);
    });
  });
}