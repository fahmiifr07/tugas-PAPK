import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('AnimatedContainer Tests', () {
    testWidgets('AnimatedContainer should have correct initial properties', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Find the AnimatedContainer
      final animatedContainer = tester.widget<AnimatedContainer>(
        find.byType(AnimatedContainer)
      );
      
      // Verify initial properties
      expect(animatedContainer.duration, const Duration(seconds: 1));
      expect(animatedContainer.curve, Curves.easeInOut);
      
      // Verify decoration properties
      final decoration = animatedContainer.decoration as BoxDecoration;
      expect(decoration.color, Colors.blue);
      expect(decoration.borderRadius, BorderRadius.circular(12));
    });
    
    testWidgets('AnimatedContainer should change properties when button is pressed', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Get initial container properties
      var animatedContainer = tester.widget<AnimatedContainer>(
        find.byType(AnimatedContainer)
      );
      var decoration = animatedContainer.decoration as BoxDecoration;
      expect(decoration.color, Colors.blue);
      
      // Press the "Ubah Tampilan" button
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Get updated container properties
      animatedContainer = tester.widget<AnimatedContainer>(
        find.byType(AnimatedContainer)
      );
      decoration = animatedContainer.decoration as BoxDecoration;
      expect(decoration.color, Colors.green);
      
      // Verify animation duration is still correct
      expect(animatedContainer.duration, const Duration(seconds: 1));
      
      // Verify borderRadius is still correct
      expect(decoration.borderRadius, BorderRadius.circular(12));
    });
    
    testWidgets('AnimatedContainer should toggle back to original properties on second button press', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Press button twice
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Verify properties are back to original values
      final animatedContainer = tester.widget<AnimatedContainer>(
        find.byType(AnimatedContainer)
      );
      final decoration = animatedContainer.decoration as BoxDecoration;
      expect(decoration.color, Colors.blue);
    });
    
    testWidgets('AnimatedContainer should have proper content and styling', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Verify the container has the correct child content
      expect(find.text('Area Konten'), findsOneWidget);
      
      // Verify the text styling within the container
      final textWidget = tester.widget<Text>(find.text('Area Konten'));
      expect(textWidget.style?.color, Colors.white);
      expect(textWidget.style?.fontSize, 16);
      expect(textWidget.style?.fontWeight, FontWeight.bold);
      
      // Verify AnimatedContainer properties
      final animatedContainer = tester.widget<AnimatedContainer>(
        find.byType(AnimatedContainer)
      );
      expect(animatedContainer.duration, const Duration(seconds: 1));
      expect(animatedContainer.curve, Curves.easeInOut);
    });
  });
}