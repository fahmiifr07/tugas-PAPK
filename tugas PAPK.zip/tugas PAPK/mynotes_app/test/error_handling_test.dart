import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Error Handling Tests', () {
    testWidgets('setState error handling does not break normal operation', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());
      
      // Verify initial state
      expect(find.byType(TextField), findsOneWidget);
      expect(find.text('Ubah Tampilan'), findsOneWidget);
      expect(find.text('Area Konten'), findsOneWidget);
      
      // Test normal TextField operation
      await tester.enterText(find.byType(TextField), 'Test User');
      await tester.pump();
      
      // Test normal button operation
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Verify greeting appears
      expect(find.text('Halo, Test User!'), findsOneWidget);
      
      // Test multiple button presses (should not cause errors)
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // App should still be functional
      expect(find.text('Halo, Test User!'), findsOneWidget);
      expect(find.text('Area Konten'), findsOneWidget);
    });
    
    testWidgets('TextField input changes work correctly with error handling', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Test various inputs
      await tester.enterText(find.byType(TextField), 'John');
      await tester.pump();
      
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, John!'), findsOneWidget);
      
      // Change name and test again
      await tester.enterText(find.byType(TextField), 'Jane');
      await tester.pump();
      
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      expect(find.text('Halo, Jane!'), findsOneWidget);
    });
    
    testWidgets('Empty input is handled gracefully', (WidgetTester tester) async {
      await tester.pumpWidget(const MyNotesApp());
      
      // Test with empty input
      await tester.enterText(find.byType(TextField), '');
      await tester.pump();
      
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();
      
      // Should show greeting with empty name
      expect(find.text('Halo, !'), findsOneWidget);
      
      // App should still be functional
      expect(find.text('Area Konten'), findsOneWidget);
    });
  });
}