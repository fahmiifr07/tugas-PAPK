import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Layout Tests', () {
    testWidgets('Column layout should have proper structure', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Verify that Column exists
      expect(find.byType(Column), findsOneWidget);

      // Verify all required widgets are present
      expect(find.byType(TextField), findsOneWidget);
      expect(find.byType(ElevatedButton), findsOneWidget);
      expect(find.byType(AnimatedContainer), findsOneWidget);

      // Verify TextField has proper decoration
      final textField = tester.widget<TextField>(find.byType(TextField));
      expect(textField.decoration?.labelText, equals('Masukkan nama Anda'));

      // Verify button has proper text
      expect(find.text('Ubah Tampilan'), findsOneWidget);

      // Verify AnimatedContainer has proper content
      expect(find.text('Area Konten'), findsOneWidget);
    });

    testWidgets('Column layout should be responsive', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Get the Column widget
      final column = tester.widget<Column>(find.byType(Column));
      
      // Verify MainAxisAlignment is center
      expect(column.mainAxisAlignment, equals(MainAxisAlignment.center));
      
      // Verify CrossAxisAlignment is stretch for responsive layout
      expect(column.crossAxisAlignment, equals(CrossAxisAlignment.stretch));
    });

    testWidgets('Layout should have proper spacing', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Verify SizedBox widgets for spacing exist
      expect(find.byType(SizedBox), findsWidgets);

      // Verify SafeArea is used for proper padding
      expect(find.byType(SafeArea), findsOneWidget);

      // Verify Padding is applied
      expect(find.byType(Padding), findsOneWidget);
    });
  });
}