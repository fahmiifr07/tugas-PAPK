import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mynotes_app/main.dart';

void main() {
  group('Text Widget for Greeting Tests', () {
    testWidgets('Greeting should not be visible initially', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Initially, greeting should not be visible
      expect(find.textContaining('Halo,'), findsNothing);
    });

    testWidgets('Greeting should appear after button press with correct format', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Enter a name
      await tester.enterText(find.byType(TextField), 'John');
      await tester.pump();

      // Tap the button to trigger display change
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Verify greeting appears with correct format
      expect(find.text('Halo, John!'), findsOneWidget);
    });

    testWidgets('Greeting should have correct styling', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Enter a name and trigger display
      await tester.enterText(find.byType(TextField), 'Alice');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Find the greeting text widget
      final greetingFinder = find.text('Halo, Alice!');
      expect(greetingFinder, findsOneWidget);

      // Get the Text widget and verify styling
      final Text greetingWidget = tester.widget(greetingFinder);
      expect(greetingWidget.style?.fontSize, equals(20));
      expect(greetingWidget.style?.fontWeight, equals(FontWeight.bold));
    });

    testWidgets('Greeting should update when name changes', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Enter first name and trigger display
      await tester.enterText(find.byType(TextField), 'Bob');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Verify first greeting
      expect(find.text('Halo, Bob!'), findsOneWidget);

      // Change the name
      await tester.enterText(find.byType(TextField), 'Charlie');
      await tester.pump();

      // The greeting should still show the old name until button is pressed again
      expect(find.text('Halo, Bob!'), findsOneWidget);
      expect(find.text('Halo, Charlie!'), findsNothing);

      // Press button again to update greeting
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Now greeting should show new name
      expect(find.text('Halo, Charlie!'), findsOneWidget);
      expect(find.text('Halo, Bob!'), findsNothing);
    });

    testWidgets('Greeting should handle empty name correctly', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Don't enter any name, just press button
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Verify greeting appears with empty name
      expect(find.text('Halo, !'), findsOneWidget);
    });

    testWidgets('Greeting should handle whitespace-only name', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Enter whitespace-only name
      await tester.enterText(find.byType(TextField), '   ');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Verify greeting appears with whitespace
      expect(find.text('Halo,    !'), findsOneWidget);
    });

    testWidgets('Greeting should handle special characters in name', (WidgetTester tester) async {
      // Build the app
      await tester.pumpWidget(const MyNotesApp());

      // Enter name with special characters
      await tester.enterText(find.byType(TextField), 'José-María');
      await tester.tap(find.text('Ubah Tampilan'));
      await tester.pump();

      // Verify greeting appears correctly with special characters
      expect(find.text('Halo, José-María!'), findsOneWidget);
    });
  });
}