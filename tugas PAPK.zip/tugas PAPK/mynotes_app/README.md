# 📱 MyNotes App - Flutter

Aplikasi catatan sederhana yang dibuat dengan Flutter, dilengkapi dengan fitur edit dan save otomatis.

## ✨ Fitur

- ✅ **Tambah Catatan** - Buat catatan baru dengan judul dan konten
- ✅ **Edit Catatan** - Edit catatan yang sudah ada  
- ✅ **Hapus Catatan** - Hapus catatan yang tidak diperlukan
- ✅ **Save Otomatis** - Catatan tersimpan otomatis di browser
- ✅ **Validasi Form** - Validasi input dengan error messages
- ✅ **Responsive UI** - Tampilan yang responsif dan bersih
- ✅ **Navigation** - Navigasi antar halaman yang smooth
- ✅ **Timestamp Tracking** - Menampilkan waktu dibuat dan diperbarui

## 🚀 Cara Menjalankan

### Prerequisites
- Flutter SDK (versi 3.0 atau lebih baru)
- Chrome Browser

### Langkah-langkah
1. Clone repository ini
2. Buka terminal di folder project
3. Jalankan command berikut:

```bash
flutter clean
flutter pub get
flutter run -d chrome --release
```

## 🛠️ Teknologi yang Digunakan

- **Flutter** - UI Framework
- **Dart** - Programming Language  
- **localStorage** - Web Storage (untuk web)
- **Material Design** - UI Components
- **Cross-platform Storage** - Abstraction layer untuk storage

## 📱 Platform Support

- ✅ **Web** (Chrome, Firefox, Safari) - dengan persistent storage
- ✅ **Android** - dengan in-memory storage
- ✅ **iOS** - dengan in-memory storage

## 🎯 Cara Menggunakan

### Menambah Catatan:
1. Klik tombol **"+ Tambah Catatan"**
2. Isi **judul** (minimal 3 karakter)
3. Isi **konten** (minimal 10 karakter)
4. Klik **"Simpan Catatan"**

### Mengedit Catatan:
1. Klik **catatan** dari daftar
2. Di halaman detail, klik tombol **"Edit"** (✏️)
3. Ubah judul dan/atau konten
4. Klik **"Simpan Perubahan"**

### Menghapus Catatan:
1. Klik **catatan** dari daftar
2. Di halaman detail, klik tombol **"Delete"** (🗑️)
3. Konfirmasi penghapusan

## 📂 Struktur Project

```
lib/
├── main.dart                    # Main app & homepage
├── add_note_view_simple.dart    # Add/Edit note form
├── note_detail_view.dart        # Note detail view
├── storage_service_simple.dart  # Storage abstraction
├── storage_web.dart            # Web storage implementation
├── storage_mobile.dart         # Mobile storage implementation
├── custom_error_widget.dart    # Custom error handling
└── no_overflow_wrapper.dart    # UI overflow prevention
```

## 🔧 Fitur Teknis

- **Cross-platform Storage** - Menggunakan localStorage di web, in-memory di mobile
- **Form Validation** - Real-time validation dengan error messages
- **State Management** - Menggunakan StatefulWidget dan setState
- **Navigation** - Named routes dan route generation
- **Error Handling** - Custom error widgets dan overflow prevention
- **Responsive Design** - Adaptif untuk berbagai ukuran layar

## 🚨 Catatan Penting

- **Web Platform**: Catatan tersimpan secara persistent di localStorage
- **Mobile Platform**: Catatan tersimpan sementara (hilang saat restart app)
- **Untuk production mobile**: Perlu implementasi shared_preferences atau database

## 👨‍💻 Developer

Dikembangkan sebagai tugas pembelajaran Flutter dengan fokus pada:
- State management
- Navigation
- Form handling
- Cross-platform development
- Storage abstraction

## 📄 License

MIT License - Feel free to use this project for learning purposes.